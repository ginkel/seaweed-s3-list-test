#! /bin/bash
for n in {1..10}; do
    dd if=/dev/urandom of=file$( printf %03d "$n" ).bin bs=1 count=1
done
